
###############################################################################

	This is a preview of 'Top-down sports pack', currently in production.

	It will include as many sports as possible seen from a top-down perspective.

			------------------------------

			        License (CC0)
	       http://creativecommons.org/publicdomain/zero/1.0/

	You may use these graphics in personal and commercial projects.
	Credit (Kenney or www.kenney.nl) would be nice but is not mandatory.

###############################################################################